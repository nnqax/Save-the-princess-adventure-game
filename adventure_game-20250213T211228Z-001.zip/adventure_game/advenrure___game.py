import time
import random
def print_pause(text):
    #Pause the game for a given text
    print(text)
    time.sleep(2)
def print_pauseq(text):
    #Pause the game for a given text with a shorter delay
    print(text)
    time.sleep(1)
def ending_gift():
    #generate a random gift for the player
    while True:
        ch=input('enter a number between 1 and 5')
        if ch=='1':
            print_pause('you got a diamond')
        elif ch=='2':
            print_pause('you got a new armor')
        elif ch=='3':
            print_pause('you got alot of gold')
        elif ch=='4':
            print_pause('you got a pricey piece of art')
        elif ch=='5':
            print_pause('you got a magical plant')
        else:
            print_pauseq('invalid input')
            print_pauseq('enter a number between 1 and 5')
def game():
    #The main game logic
    score=0
    def plus_score():
        #makes the score add 1
        nonlocal score
        score=score+1
        print('your score='+ str(score))
    def minus_score():
        #makes the score minused by 1
        nonlocal score
        score=score-1
        print('your score='+ str(score))
    def ending():
        #makes the ending of a game
        print_pause('Game Over')
        print_pause('thank you for playing')
        ending_gift()
        print_pause('Do you wanna replay?')
        while True:
            ch=input('enter y or n')
            if ch=='y':
                game()
            elif ch=='n':
                exit()
            else:
                ('enter y or n')
    def knight():
        #handles the knight choice
        power=['SaS','KaH']
        randpower=random.choice(power)
        while True:
            if randpower=='SaS':
                print_pause('you have the Sword Mastery and Shield Defense')
                print_pause('you have an Exceptional combat skills')
                print_pause('with a variety of melee weapon')
                print_pause('and you have an Ability to block')
                print_pause('and parry attacks effectively,')
                print_pause('reducing damage taken')
                print_pause('the king asked for you to come')
                print_pause('then told that')
                print_pause('the evil dragon stole the princess')
                print_pause('and he wants you to bring her back')
                print_pause('what should you do')
                print_pause('1.refuse to go')
                print_pause('2.agree to go')
                while True:
                    ch=input('enter 1 or 2')
                    if ch=='1':
                        minus_score()
                        print_pause('he got angry')
                        print_pause('and excuted you')
                        break
                    elif ch=='2':
                        plus_score()
                        print_pause('you went out to the forest')
                        print_pause('you walked for along time')
                        print('till you saw a tower')
                        print_pause('what should you do?')
                        print_pause('1.go inside the tower')
                        print_pause('2.dont go in')
                        while True:
                            ch=input('enter 1 or 2')
                            if ch=='1':
                                plus_score()
                                print_pause('you went into the tower')
                                print_pause('there was a witch')
                                print_pause('she told yo that she can help')
                                print_pause('you two marched to the cave')
                                print_pause('that the dragon was in')
                                print_pause('it came out and tried to attack')
                                print_pause('what should you do?')
                                print_pause('1.run')
                                print_pause('2.fight')
                                while True:
                                    ch=input('enter 1 or 2')
                                    if ch=='1':
                                        minus_score()
                                        print_pause('it flought towards you')
                                        print_pauseq('The dragon breathed')
                                        print_pause('flames at you')
                                        print_pause('you got killed')
                                        break
                                    elif ch=='2':
                                        plus_score()
                                        print_pauseq('you and the witch')
                                        print_pause('fought it')
                                        print_pause('it breathed flames')
                                        print_pause('but you used your shield')
                                        print_pauseq('then the witch')
                                        print_pauseq('used her magic')
                                        print_pause('she freezed it')
                                        print_pause('you used your sword')
                                        print_pause('and killed it')
                                        print_pauseq('then you freed')
                                        print_pauseq('the princess')
                                        print_pause('and went home')
                                        break
                                    else:
                                        print_pause('invalid input')
                            elif ch=='2':
                                minus_score()
                                print_pause('you completed your road')
                                print_pause('when you reached the dragons')
                                print_pause('cave, it tried to')
                                print_pause('breath flames on you')
                                print_pause('what should you do?')
                                print_pause('1.run')
                                print_pause('2.fight')
                                while True:
                                    ch=input('enter 1 or 2')
                                    if ch=='1':
                                        minus_score()
                                        print_pause('it flought towards you')
                                        print_pauseq('The dragon breathed')
                                        print_pause('flames at you')
                                        print_pause('you got killed')
                                        break
                                    elif ch=='2':
                                        plus_score()
                                        print_pause('it breathed flames')
                                        print_pause('at you')
                                        print_pause('but you used your sheild')
                                        print_pause('you did not know')
                                        print_pause('how to fight it')
                                        print_pause('but then')
                                        print_pause('you saw the princess')
                                        print_pause('she ran to distract it')
                                        print_pauseq('you quickly killed it')
                                        print_pause('with your sword')
                                        print_pause('and freed the princess')
                                        break
                                    else:
                                        print_pause('invalid input')
                    else:
                        print('invalid input')
            else:
                print_pause('you have the Knightly Oath and Holy Magic')
                print_pause('you can Gain buffs')
                print_pause('when fighting alongside allies,')
                print_pause('increasing morale and combat effectiveness')
                print_pause('and Unlock magical abilities to heal allies')
                print_pause('and deal damage to undead or dark creatures')
                print_pause('the king asked for you to come')
                print_pause('then told that')
                print_pause('the evil dragon stole the princess')
                print_pause('and he wants you to bring her back')
                print_pause('what should you do')
                print_pause('1.refuse to go')
                print_pause('2.agree to go')
                while True:
                    ch=input('enter 1 or 2')
                    if ch=='1':
                        minus_score()
                        print_pause('he got angry')
                        print_pause('and excuted you')
                        break
                    elif ch=='2':
                        plus_score()
                        print_pause('you went out to the forest')
                        print_pause('you walked for along time')
                        print_pause('till you saw a tower')
                        print_pause('what should you do?')
                        print_pause('1.go inside the tower')
                        print_pause('2.dont go in')
                        while True:
                            ch=input('enter 1 or 2')
                            if ch=='1':
                                plus_score()
                                print_pause('you went into the tower')
                                print_pause('there was a wizard')
                                print_pause('he told you that she can help')
                                print_pause('you two marched to the cave')
                                print_pause('that the dragon was in')
                                print_pause('it came out and tried to attack')
                                print_pause('what should you do?')
                                print_pause('1.run')
                                print_pause('2.fight')
                                while True:
                                    ch=input('enter 1 or 2')
                                    if ch=='1':
                                        minus_score()
                                        print_pause('it flought towards you')
                                        print_pauseq('The dragon breathed')
                                        print_pause('flames at you')
                                        print_pause('but you reversed that')
                                        print_pause('and killed it')
                                        print_pauseq('but your reverse magic')
                                        print_pause('and killed her')
                                        break
                                    elif ch=='2':
                                        plus_score()
                                        print_pauseq('you and the witch')
                                        print_pause('fought it')
                                        print_pause('it breathed flames')
                                        print_pause('but you used your shield')
                                        print_pauseq('then the wizard')
                                        print_pauseq('used his magic')
                                        print_pause('he freezed it')
                                        print_pause('you used your magic')
                                        print_pause('and killed it')
                                        print_pauseq('then you freed')
                                        print_pauseq('the princess')
                                        print_pause('and went home')
                                        break
                                    else:
                                        print_pause('invalid input')
                            elif ch=='2':
                                minus_score()
                                print_pause('you completed your road')
                                print_pause('when you reached the dragons')
                                print_pause('cave, it tried to')
                                print_pause('breath flames on you')
                                print_pause('what should you do?')
                                print_pause('1.run')
                                print_pause('2.fight')
                                while True:
                                    ch=input('enter 1 or 2')
                                    if ch=='1':
                                        minus_score()
                                        print_pause('it flought towards you')
                                        print_pauseq('The dragon breathed')
                                        print_pause('flames at you')
                                        print_pause('but you reversed that')
                                        print_pause('and killed it')
                                        print_pauseq('but your reverse magic')
                                        print_pause('and killed her')
                                        break
                                    elif ch=='2':
                                        plus_score()
                                        print_pause('it breathed flames')
                                        print_pause('at you')
                                        print_pauseq('you quickly killed it')
                                        print_pause('with your magic')
                                        print_pause('and freed the princess')
                                        break
                                    else:
                                        print_pause('invalid input')
                    else:
                        print('invalid input')
    def wizard():
        #handles the wizard choice
        power=['N','IaE']
        randpower=random.choice(power)
        while True:
            if randpower=='N':
                print_pause('You have Nature Magic')
                print_pause('you have the Ability to manipulate plants')
                print_pause('and elements for healing, defense, and offense')
                print_pause('you were planting your plants')
                print_pause('when you saw someone was coming')
                print_pause('what should you do?')
                print_pause('1.close your tower')
                print_pause('2.see what they want')
                while True:
                    ch=input('enter 1 or 2')
                    if ch=='1':
                        minus_score()
                        print_pause('you closed the door with your magic')
                        print_pause('and just continuoed what you were doing')
                        break
                    elif ch=='2':
                        plus_score()
                        print_pause('it was a knight')
                        print_pause('he wanted to go to free a princess')
                        print_pause('he asked you to help him')
                        print_pause('what should you do?')
                        print_pause('1.refuse to go')
                        print_pause('2.go with him')
                        while True:
                            ch=input('enter 1 or 2')
                            if ch=='1':
                                minus_score()
                                print_pause('he told you okay and went out')
                                print_pauseq('and you just continued')
                                print_pause('you were doing')
                                break
                            elif ch=='2':
                                plus_score()
                                print_pause('you agreed and went with him')
                                print_pause('once you arrived')
                                print_pause('at the dragons cave')
                                print_pause('it came out from the cave')
                                print_pause('what should you do?')
                                print_pause('1.run')
                                print_pause('2.fight')
                                while True:
                                    ch=input('enter 1 or 2')
                                    if ch=='1':
                                        minus_score()
                                        print_pause('you ran but')
                                        print_pause('it followed you')
                                        print_pause('you tried')
                                        print_pause('to control the fire')
                                        print_pause('but it was powerful')
                                        print_pause('you got killed')
                                        break
                                    elif ch=='2':
                                        plus_score()
                                        print_pause('the knight used his')
                                        print_pause('shield to protect you')
                                        print_pause('you freezed the dragon')
                                        print_pause('with your magic')
                                        print_pause('then the knight jumped')
                                        print_pause('and killed the dragon')
                                        print_pause('then freed the princess')
                                        break
                                    else:
                                        print_pause('invalid input')
                            else:
                                print_pause('invalid input')
                    else:
                        print_pause('invalid input')
            else:
                print_pause('you have Illusions and Enchantments power')
                print_pause('you can Cast spells to confuse enemies')
                print_pause('or enhance allies,')
                print_pause('allowing for strategic advantages in combat')
                print_pause('you were planting your plants')
                print_pause('when you saw someone was coming')
                print_pause('what should you do?')
                print_pause('1.close your tower')
                print_pause('2.see what they want')
                while True:
                    ch=input('enter 1 or 2')
                    if ch=='1':
                        minus_score()
                        print_pause('you closed the door with your magic')
                        print_pause('and just continuoed what you were doing')
                        break
                    elif ch=='2':
                        plus_score()
                        print_pause('it was a knight')
                        print_pause('he wanted to go to free a princess')
                        print_pause('he asked you to help him')
                        print_pause('what should you do?')
                        print_pause('1.refuse to go')
                        print_pause('2.go with him')
                        while True:
                            ch=input('enter 1 or 2')
                            if ch=='1':
                                minus_score()
                                print_pause('he told you okay and went out')
                                print_pauseq('and you just continued')
                                print_pause('you were doing')
                                break
                            elif ch=='2':
                                plus_score()
                                print_pause('you agreed and went with him')
                                print_pause('once you arrived')
                                print_pause('at the dragons cave')
                                print_pause('it came out from the cave')
                                print_pause('what should you do?')
                                print_pause('1.run')
                                print_pause('2.fight')
                                while True:
                                    ch=input('enter 1 or 2')
                                    if ch=='1':
                                        minus_score()
                                        print_pause('you ran but')
                                        print_pause('it followed you')
                                        print_pause('you casted a spell')
                                        print_pause('to make him slower')
                                        print_pause('and continued running')
                                        print_pause('then got to the tower')
                                        print_pause('and looked it')
                                        break
                                    elif ch=='2':
                                        plus_score()
                                        print_pause('the knight used his')
                                        print_pause('shield to protect you')
                                        print_pause('you freezed the dragon')
                                        print_pause('with your magic')
                                        print_pause('then the knight jumped')
                                        print_pause('and killed the dragon')
                                        print_pause('then freed the princess')
                                        break
                                    else:
                                        print_pause('invalid input')
                            else:
                                print_pause('invalid input')
                    else:
                        print_pause('invalid input')


    print_pause('who are you?')
    print_pause('1.I am a wizard/witch')
    print_pause('2.I am a knight')
    while True:
        choice=input('enter 1 or 2')
        if choice=='1':
            knight()
            ending()
        elif choice=='2':
            wizard()
            ending()
        else:
            print_pause('invalid input')